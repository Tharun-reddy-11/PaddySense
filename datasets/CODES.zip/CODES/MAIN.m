clear
close all



%%%%%%%%%%%%%%%%%%%%%%%%%%% PATCH
    disp('Now processing TABULATE_2_Patching')
    % >---- MFM (from DATA)
    % >---- FUBC18_IDV (from DATA)
    % >---- FUBC18_AGG (from DATA)
    % >---- HFUBC (from DATA)
    % >---- US (from DATA)
    % >---- BY (from DATA)
    % >---- GB (from DATA)
    % >---- AU (from DATA)
    % >---- CROPGRIDS_Tabulated_HA (from CROPGRIDS)
    TABULATE_2_Patching
    % ----> PATCHED_COUR_NPK
    
    
%%    
%%%%%%%%%%%%%%%%%%%%%%%%%%% Data filling for subnational with CROPGRIDS data but no fertilizer
%%%%%%%%%%%%%%%%%%%%%%%%%%% data using NEIGHBOR's data
    disp('Now processing TABULATE_3_NEIGHBOR')
    
    % >---- PATCHED_COUR_NPK
    % >---- CROPGRIDS_Tabulated_HA (from CROPGRIDS)
    % >---- COUR (from REMAP)
    TABULATE_3_NEIGHBOR
    % ----> NEIGHBOR_COUR_NPK
    
    
    
    
%%  
%%%%%%%%%%%%%%%%%%%%%%%%%%% Data filling for subnational with CROPGRIDS data but no fertilizer
%%%%%%%%%%%%%%%%%%%%%%%%%%% data using Crop groups data
    disp('Now processing TABULATE_4_CROPGROUP')
    
    % ----> NEIGHBOR_COUR_NPK
    % >---- CROPGRIDS_Tabulated_HA (from CROPGRIDS)
    % >---- COUR (from REMAP)
    % >---- COU (from REMAP)
    TABULATE_4_CROPGROUP
    % ----> CROPGROUP_COUR_NPK.mat
    
    
    
    
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% Calculate Data quality
    disp('Now processing TABULATE_5_FinalDataQuality.m')
    
    % >---- CROPGROUP_COUR_NPK.mat
    % >---- CROPGRIDS_Tabulated_HA (from CROPGRIDS)
    % >---- COUR (from REMAP)
    % >---- COU (from REMAP)
    TABULATE_5_FinalDataQuality
    % ----> Final_COUR_NPK_v2.mat
    
    
    
%%
%%%%%%%%%%%%%%%%%%%%%%%%%%% Spatialise data
    disp('Now processing MAP_6_Spatialization')
    
    % >---- Final_COUR_NPK_v2.mat
    % >---- COUR (from REMAP)
    MAP_6_Spatialization
    
    

    

clear
close all


ftype = {'N','P2O5','K2O'};



folder_here    = cd;
folder_REMAP   = '../REMAP_0p05x0p05';
folder_RAW     = 'RAW1';




mkdir(folder_RAW)

% LOAD PATCHING DATA
load('Final_COUR_NPK_v2.mat')    
    % % % % %   COUR_Qq            1x3               10000512  cell               
    % % % % %   COUR_frate         1x3               10000512  cell               
    % % % % %   COUR_set_num       1x3              133480400  cell               
    % % % % %   COUR_set_text      1x3              133711456  cell               
    % % % % %   Crop               1x175                20718  cell               
    % % % % %   sets               1x10                  1146  cell           


% check completeness
a = COUR_frate{1};
b = COUR_frate{2};
c = COUR_frate{3};

a(isnan(a)) = 0;
b(isnan(b)) = 0;
c(isnan(c)) = 0;

d = logical(a) + logical(b) + logical(c);
e = sum(sum(d<3 & d>0));
if e == 0
   disp('N P K have data in the same COUR and CROP') 
end
    



% LOAD COUR
cd(folder_REMAP)
    load COUR
    tmp     = COUR_Info.ImageDescription;
    COUR_ID = cellfun(@(x) extractBefore(x,' -'),tmp,'UniformOutput',false);

% LOAD CROPGRID Maps
    m   = matfile('CROPGRIDS.mat');
    tmp = whos(m);
    Info = m.CRO_HA_Info;
    CROPS = Info.ImageDescription;
    nCROPS = length(CROPS);
cd(folder_here)    


clear Crops tmp


VERSION = 'v1.08';


%%



    
    
%% SPATIALISE

k      = 1;
N_rate = COUR_frate{k};
N_qual = COUR_Qq{k};  

k      = 2;
P_rate = COUR_frate{k};
P_qual = COUR_Qq{k};  

k      = 3;
K_rate = COUR_frate{k};
K_qual = COUR_Qq{k};  


%% OPEN CLUSTER AND RUN JOB

save DATA_SPATIALIZE

c = parcluster;
j = createJob(c);
for i=1:175
   createTask(j,@build_data,0,{i});
end
submit(j)
%wait(j)
%fetchOutputs(j)

%delete DATA_SPATIALIZE



%%
%%
%%

function [] = build_data(index)

    load DATA_SPATIALIZE
    
    for i=index
    %for i=1
            disp(['Now processing ' num2str(i) ' ' CROPS{i}])


            HA_map = squeeze( m.CRO_HA_map_GGi(i,:,:));
            %HA_map = gpuArray(HA_map);

            % allocate rate and qual
            MAP_COUR  = single(COUR_map_GGi) .* (HA_map>0);
            %MAP_COUR  = gpuArray(MAP_COUR);
            COUR_list = unique(MAP_COUR);
            COUR_list = COUR_list(COUR_list>0);

            % initialize
            MAP_rate_N  = HA_map * 0;
            MAP_qual_N  = MAP_rate_N;
            MAP_rate_P  = MAP_rate_N;
            MAP_qual_P  = MAP_rate_N;
            MAP_rate_K  = MAP_rate_N;
            MAP_qual_K  = MAP_rate_N;

            if ~isempty(COUR_list)
            for j = COUR_list'

                % allocate rate
                jcour = find(MAP_COUR == j);
                MAP_rate_N(jcour) = N_rate(j,i);
                MAP_rate_P(jcour) = P_rate(j,i);
                MAP_rate_K(jcour) = K_rate(j,i);

                % allocate qual
                jcour = find(COUR_map_GGi == j);
                MAP_qual_N(jcour) = N_qual(j,i);
                MAP_qual_P(jcour) = P_qual(j,i);
                MAP_qual_K(jcour) = K_qual(j,i);
            end
            end


            cd(folder_RAW)
                k = 1;
                MAP_rate = MAP_rate_N;
                MAP_qual = MAP_qual_N;

                %MAP_rate = gather(MAP_rate);
                %MAP_qual = gather(MAP_qual);

                save(['NPKGRIDS' VERSION '_' CROPS{i} '_' ftype{k} '_rate_qual.mat'],'MAP_rate','MAP_qual')
                clear MAP_rate_N MAP_qual_N

                k = 2;
                MAP_rate = MAP_rate_P;
                MAP_qual = MAP_qual_P;

                %MAP_rate = gather(MAP_rate);
                %MAP_qual = gather(MAP_qual);

                save(['NPKGRIDS' VERSION '_' CROPS{i} '_' ftype{k} '_rate_qual.mat'],'MAP_rate','MAP_qual')
                clear MAP_rate_P MAP_qual_P

                k = 3;
                MAP_rate = MAP_rate_K;
                MAP_qual = MAP_qual_K;

                %MAP_rate = gather(MAP_rate);
                %MAP_qual = gather(MAP_qual);

                save(['NPKGRIDS' VERSION '_' CROPS{i} '_' ftype{k} '_rate_qual.mat'],'MAP_rate','MAP_qual')
                clear MAP_rate_K  MAP_qual_K

            cd(folder_here)

        end

end
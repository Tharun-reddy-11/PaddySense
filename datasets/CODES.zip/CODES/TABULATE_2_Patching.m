clear 
close all



folder_here = cd;
folder_CROPGRIDS = '../DATA/CROPGRIDS';

sets{1} = 'MFM';
sets{2} = 'FUBC18_IDV';
sets{3} = 'FUBC18_AGG';
sets{4} = 'HFUBC';
sets{5} = 'US';
sets{6} = 'BY';
sets{7} = 'GB';
sets{8} = 'AU';
%sets{9} = 'FUBC18_IDV, HFUBC';

nsets    = length(sets);


folder_sets{1} = '../DATA/Mueller_etal_2012/';
folder_sets{2} = '../DATA/FUBC18/';
folder_sets{3} = '../DATA/FUBC18/';
folder_sets{4} = '../DATA/HFUBC/';
folder_sets{5} = '../DATA/National_Data/USA/';
folder_sets{6} = '../DATA/National_Data/Belarus/';
folder_sets{7} = '../DATA/National_Data/GreatBritain/';
folder_sets{8} = '../DATA/National_Data/Australia/';
%folder_sets{9} = [];


% Load CROPGRIDS
cd(folder_CROPGRIDS)
    load CROPGRIDS_Tabulated_HA.mat

    COUR_CR_LO = COUR_CR_HA>0;  % CROPGRIDS mask
cd(folder_here)
    





        %%

        % Loop each nutrient
        ftype = {'N','P2O5','K2O'};
        %for m = 1:length(ftype)
        for m = 1:3
        %     m=1;


            f = ftype{m};

        %% Step 1: Load data

            for d = 1:nsets
                if d<=8
                cd(folder_sets{d})
                    load([sets{d} '_COUR_NPK.mat'])
                    COUR_frate_all{m}(d,:,:) = COUR_frate{m};
                    COUR_year_all{m}(d,:,:)  = COUR_year{m};
                cd(folder_here)
                end
            end



         %% Step 2: Data qualities
         % Qc: Crop specification. Qc = 1: crop-specific, 0.5 = aggregation
            Qc        = [];
            Qc(1,:,:) = COUR_frate_all{m}(1,:,:)./COUR_frate_all{m}(1,:,:);  %MFM, Qc = 1
            Qc(2,:,:) = COUR_frate_all{m}(2,:,:)./COUR_frate_all{m}(2,:,:);  %FUBC18_IDV, Qc = 1
            Qc(3,:,:) = COUR_frate_all{m}(3,:,:)./COUR_frate_all{m}(3,:,:).*0.5;  %FUBC18_AGG, Qc = 0.5
            Qc(4,:,:) = COUR_frate_all{m}(4,:,:)./COUR_frate_all{m}(4,:,:);  %HFUBC, Qc = 1
            Qc(5,:,:) = COUR_frate_all{m}(5,:,:)./COUR_frate_all{m}(5,:,:);  %US, Qc = 1
            Qc(6,:,:) = COUR_frate_all{m}(6,:,:)./COUR_frate_all{m}(6,:,:);  %BY, Qc = 1
            Qc(7,:,:) = COUR_frate_all{m}(7,:,:)./COUR_frate_all{m}(7,:,:);  %GB, Qc = 1 except Rye(138),Triticale (163)
                % Correct Qc = 0.5 for these two crops for GB
                    tmp = find(Qc(7,:,138)>0 );
                    Qc(7,tmp,138) = 0.5;
                    tmp = find(Qc(7,:,163)>0 );
                    Qc(7,tmp,163) = 0.5;
            Qc(8,:,:) = COUR_frate_all{m}(8,:,:)./COUR_frate_all{m}(8,:,:);  %AU, Qc = 1 

         % Qa: Data administration
            Qr = [];
            Qr(1,:,:) = COUR_frate_all{m}(1,:,:)./COUR_frate_all{m}(1,:,:).*0.75;  %MFM, Qr = 0.75
            Qr(2,:,:) = COUR_frate_all{m}(2,:,:)./COUR_frate_all{m}(2,:,:).*0.5;  %FUBC18_IDV, Qr = 0.5
            Qr(3,:,:) = COUR_frate_all{m}(3,:,:)./COUR_frate_all{m}(3,:,:).*0.5;  %FUBC18_AGG, Qr = 0.5
            Qr(4,:,:) = COUR_frate_all{m}(4,:,:)./COUR_frate_all{m}(4,:,:).*0.5;  %HFUBC, Qr = 0.5
            Qr(5,:,:) = COUR_frate_all{m}(5,:,:)./COUR_frate_all{m}(5,:,:);  %US, Qr = 1
            Qr(6,:,:) = COUR_frate_all{m}(6,:,:)./COUR_frate_all{m}(6,:,:);  %BY, Qr = 1
            Qr(7,:,:) = COUR_frate_all{m}(7,:,:)./COUR_frate_all{m}(7,:,:);  %GB, Qr = 1
            Qr(8,:,:) = COUR_frate_all{m}(8,:,:)./COUR_frate_all{m}(8,:,:);  %AU, Qr = 1 

         % Qy: Synchrony
            Qy = [];
            Qy = (COUR_year_all{m}-2000)/(2015-2000);
            Qy(Qy>1) = 1;

         % Qk
            Qc(isnan(Qc)) = 0;
            Qr(isnan(Qr)) = 0;
            Qy(isnan(Qy)) = 0; 
            Qk = (Qc+Qr+Qy)/3;  %The overall endogenous data quality


        %% Patching FOR AVERAGE OF DATASETS OF EQUAL Qk
            COUR_frate_ave{m} = COUR_frate{m}*nan;
            COUR_Qk_ave{m}    = COUR_frate{m}*nan;
            % weight
            Qk_weight{m}        = Qk.*0;
            frate_weight{m}     = Qk.*0;

            COUR_set_text{m}    = cell(size(COUR_frate{m},1),size(COUR_frate{m},2));    % sets in text
            COUR_set_text_detail{m} = COUR_set_text{m}; % sets in text with detail of weight

            tmp = COUR_set_text{m};
            COUR_set_num{m}(1:size(tmp,1), 1:size(tmp,2)) = 0;  % sets in numbers

            for j = 1:size(Qk,3)    %crops%47
                for i = 1:size(Qk,2) %COUR%115
                    
                    all_set_tmp = find(Qk(:,i,j)>0);
                    
                    if length(all_set_tmp) == 1   %if there is only one dataset
                        COUR_Qk_ave{m}(i,j)     = Qk(all_set_tmp,i,j);
                        COUR_frate_ave{m}(i,j)  = COUR_frate_all{m}(all_set_tmp,i,j);
                        COUR_set_num{m}(i,j)     = all_set_tmp;
                        COUR_set_text{m}{i,j}    = sets{all_set_tmp};
                        
                    elseif length(all_set_tmp)>1    %if there are >1 datsets
                        Qk_tmp = Qk(all_set_tmp,i,j);
                        max_Qk_tmp = max(Qk_tmp);
                        max_id = find(Qk_tmp == max_Qk_tmp);
                        if length(max_id) == 1    % if there is only one max dataset
                            COUR_Qk_ave{m}(i,j)    = Qk(all_set_tmp(max_id),i,j);
                            COUR_frate_ave{m}(i,j) = COUR_frate_all{m}(all_set_tmp(max_id),i,j);
                            COUR_set_num{m}(i,j)   = all_set_tmp(max_id);
                            
                            COUR_set_text{m}{i,j}  = sets{all_set_tmp(max_id)};
                        else    % if there are two datasets with equal max Qk
                            
                            if length(unique(COUR_year_all{m}(all_set_tmp(max_id),i,j)))>1 % datasets have different reference year --> choose more recent    
                                [~,max_year_id]         = max(COUR_year_all{m}(all_set_tmp(max_id),i,j));
                                COUR_Qk_ave{m}(i,j)     = Qk(all_set_tmp(max_id(1)),i,j);
                                COUR_frate_ave{m}(i,j)  = COUR_frate_all{m}(all_set_tmp(max_id(max_year_id)),i,j);
                                COUR_set_num{m}(i,j)    = all_set_tmp(max_id(max_year_id));
                                COUR_set_text{m}{i,j}   = sets{all_set_tmp(max_id(max_year_id))};

                            else % datasets have same reference year --> average
                                COUR_Qk_ave{m}(i,j)     = mean(Qk(all_set_tmp(max_id(1)),i,j));
                                COUR_frate_ave{m}(i,j)  = mean(COUR_frate_all{m}(all_set_tmp(max_id),i,j));
                                %COUR_set_num{m}(i,j)    = all_set_tmp(max_id);
                                COUR_set_num{m}(i,j)    = 9;
                                COUR_set_text{m}{i,j}   = sets{all_set_tmp(max_id(1))};
                                for s = 2:length(all_set_tmp(max_id))
                                    COUR_set_text{m}{i,j} = sprintf('%s, %s',COUR_set_text{m}{i,j},sets{all_set_tmp(max_id(s))});
                                end

                                disp(['Here is the case of average of datasets with id ' num2str(COUR_set_num{m}(i,j)) ' and tag ' COUR_set_text{m}{i,j} ])
                            end
                        end                             
                    end
                end
            end
        end

        
        sets{9} = 'FUBC18_IDV, HFUBC';
        
        %% Save
        save(['PATCHED_COUR_NPK.mat'],'Qk_weight','frate_weight','COUR_frate_ave','COUR_set_text','COUR_set_num','COUR_Qk_ave','COUR_frate_all','COUR_year_all', 'sets')
        

clear
close all


folder_here      = cd;
folder_REMAP     = '../REMAP_0p05x0p05';
folder_CROPGRIDS = '../DATA/CROPGRIDS';


%%% Load frate 
load('PATCHED_COUR_NPK.mat', 'COUR_frate_ave','COUR_set_text','COUR_set_num','COUR_Qk_ave','sets')   
% % %   COUR_Qk_ave         1x3              5000436  cell               
% % %   COUR_frate_all      1x3             80001936  cell               
% % %   COUR_frate_ave      1x3              5000436  cell               
% % %   COUR_set_num        1x3             52184616  cell               
% % %   COUR_set_text       1x3             51837660  cell               
% % %   COUR_year_all       1x3             80001936  cell               
% % %   Qk_weight           1x3             80001936  cell               
% % %   frate_weight        1x3             80001936  cell               
% % %   sets                1x8                  968  cell  
% COUR_Qk_ave of NEIGHBORS = 0, so load here and save as the same at the end.

% % sets{1} = 'MFM';
% % sets{2} = 'FUBC18_IDV';
% % sets{3} = 'FUBC18_AGG';
% % sets{4} = 'HFUBC';
% % sets{5} = 'US';
% % sets{6} = 'BY';
% % sets{7} = 'GB';
% % sets{8} = 'AU';
% % sets{9} = 'FUBC18_IDV HFUBC';

% now add set 10

% % sets{10} = 'NEIGHBOR';


% Load CROPGRIDS
cd(folder_CROPGRIDS)
    load CROPGRIDS_Tabulated_HA.mat
    COUR_CR_LO = COUR_CR_HA>0;  % CROPGRIDS mask
cd(folder_here)
nCROPS = length(CROP_Name);


cd(folder_REMAP)    
    load('COUR.mat')
    COUR_info = COUR_Info.ImageDescription;
    COUR_Name = cellfun(@(x) extractAfter(x,'> '),COUR_info,'UniformOutput',false);
    COUR_Name = cellfun(@strtrim,COUR_Name,'UniformOutput',false);
    COU_Name  = cellfun(@(x) extractBetween(x,': ',' >'),COUR_info,'UniformOutput',false);
    COU_Name  = [COU_Name{:}];
    nCOUR     = length(COUR_Name);
cd(folder_here)

% % save DATA_TABULATE_3
% % 
% % c = parcluster;
% % j = createJob(c);
% % for i=1:3
% %    createTask(j,@build_data,0,{i});
% % end
% % submit(j)
% % wait(j)
% % a = fetchOutputs(j)


save DATA_TABULATE_3

a = gcp;
if isempty(a) | a.NumWorkers~=3
    delete(a)
    parpool(3)
else
    parpool(3)
end

spmd
    build_data(labindex)
end


for m = 1:3
    a = load(['NEIGHBOR_COUR_NPK_partial_' num2str(m) '.mat']);
    COUR_frate_NEIG{m} = a.COUR_frate_NEIG{m};
    COUR_set_num{m}    = a.COUR_set_num{m};
    COUR_set_text{m}   = a.COUR_set_text{m};
    sets               = a.sets;
end

save(['NEIGHBOR_COUR_NPK.mat'],'COUR_frate_NEIG','COUR_set_text','COUR_set_num','COUR_Qk_ave', 'sets')




return

%%
%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%



function [] = build_data(index)

    load DATA_TABULATE_3

    ftype = {'N','P2O5','K2O'};
    for m = index


        f = ftype{m};
        disp(['Now processing ' f])

    %% Check CROPGRID and NPKGRID overlap at COUR
        Ap = double(COUR_CR_LO)*2;   % where CROPGRID area >0, VALUE = 2;
        Rnan = double(COUR_frate_ave{m}>0);    %where frate has data, VALUE = 1
        ApRnan = (Ap+Rnan); % 1: yes NPKG, no CR (should not exist); 2: no NPKG, yes CR; 3: yes NPKG, yes CR

    %% Correct those cell with ApRnan == 2 --> Choose the average frate of the closest subnational units (using centroid)
        COUR_frate_NEIG{m} = COUR_frate_ave{m};
        for i=1:nCROPS
            disp([num2str(i) ' ' CROP_Name{i}])

            missing = find(ApRnan(:,i)==2);
            exist = find(ApRnan(:,i)==3);
            if ~isempty(missing) && ~isempty(exist)
                exist_map = COUR_map_GGi;
                exist_map(~ismember(exist_map,exist))=0;
                exist_edges = double(exist_map)*0;
                %%% Map of only borders
                for ex = exist'
                    oneedge = bwperim(exist_map==ex);
                    exist_edges = exist_edges + double(oneedge)*ex;
                end
                [exist_row, exist_col] = find(exist_edges>0);
                y = delaunayn([exist_row exist_col]);
                for j = 1:length(missing)
                    miss_map = COUR_map_GGi==missing(j);
                    miss_edge = bwperim(miss_map);
                    [miss_row miss_col] = find(miss_edge>0);

                    [k, dist] = dsearchn([exist_row exist_col],y,[miss_row miss_col]);
                    id = find(dist==min(dist));
                    nearest_all = exist_edges(sub2ind(size(exist_edges),exist_row(k(id)),exist_col(k(id))));    %all pixel that have the min distance to the country border
                    frate_all = COUR_frate_ave{m}(nearest_all,i);
                    COUR_frate_NEIG{m}(missing(j),i) = mean(frate_all,'omitnan');  % frate of the missing subnational units is the average frate of the closest available subnational units, area weighted by the shared border length
                    COUR_nearest = unique(nearest_all);
                    disp(['     COURs nearest for COUR ' COUR_Name{missing(j)} ', in COU ' COU_Name{missing(j)} ', for crop ' CROP_Name{i} ' are ' COUR_Name{COUR_nearest} ', in COU ' COU_Name{COUR_nearest}])
                    COUR_set_num{m}(missing(j),i)  = 10;  %set = 10: NEIGHBOUR
                    COUR_set_text{m}{missing(j),i} = 'NEIGHBOR';
                end
            end
        end

    end

    sets{end+1} = 'NEIGHBOR';
    save(['NEIGHBOR_COUR_NPK_partial_' num2str(index) '.mat'],'COUR_frate_NEIG','COUR_set_text','COUR_set_num','COUR_Qk_ave', 'sets')


end

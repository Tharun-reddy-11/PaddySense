


folder_here         = cd;
folder_REMAP      = '../REMAP_0p05x0p05';
folder_CROPGRIDS = '../DATA/CROPGRIDS';

% Read crop classification file
[~,~,~,CropClass,TP,HST] = readvars('FAO_Crop_Classification.xlsx');

%%% Load frate 
load('NEIGHBOR_COUR_NPK.mat', 'COUR_frate_NEIG','COUR_set_text','COUR_set_num','COUR_Qk_ave','sets')   
% COUR_Qk of NEIGHBORS = 0, so load here and save as the same at the end.
% % %   COUR_Qk_ave          1x3              5000412  cell               
% % %   COUR_frate_NEIG      1x3              5000412  cell               
% % %   COUR_set_num         1x3             10000512  cell               
% % %   COUR_set_text        1x3             52435284  cell               
% % %   sets                 1x10                1162  cell


% Load CROPGRIDS
cd(folder_CROPGRIDS)
    load CROPGRIDS_Tabulated_HA.mat
    COUR_CR_LO = COUR_CR_HA>0;  % CROPGRIDS mask
cd(folder_here)
nCROPS = length(CROP_Name);




%%% Load region info
cd(folder_REMAP)
    load COU 
    tmp        = COU_Info.ImageDescription;
    COU_unique = cellfun(@(x) extractBetween(x,': ',' >'),tmp,'UniformOutput',false);
    COU_unique = [COU_unique{:}];
    
    load('COUR.mat')
    COUR_info = COUR_Info.ImageDescription;
    COUR_Name = cellfun(@(x) extractAfter(x,'> '),COUR_info,'UniformOutput',false);
    COUR_Name = cellfun(@strtrim,COUR_Name,'UniformOutput',false);
    COU_Name  = cellfun(@(x) extractBetween(x,': ',' >'),COUR_info,'UniformOutput',false);
    COU_Name  = [COU_Name{:}];
    
    nCOUR     = length(COUR_Name);
cd(folder_here)




ftype = {'N','P2O5','K2O'};
for m = 1:length(ftype)
    
    
    f=ftype{m};
   
    disp(['Now processing ' f])

%% Prepare matrices
    conflag                 = COUR_frate_NEIG{m}*0; % flag of how the data was managed. 3:average of 3-matched conditions, 2: average of 2-matched, 0: average of global 3-of-2-matched
    COUR_frate_cropgroup{m} = COUR_frate_NEIG{m};
    COUR_frate_global       = COUR_frate_NEIG{m}*0;

%% Start
%%%%%%%%%%%%%%%%%%%%5
%% Find missing crops
    Ap     = double(COUR_CR_LO)*2;
    Rnan   = double(COUR_frate_NEIG{m}>0);    %where frate has data, VALUE = 1
    ApRnan = (Ap+Rnan); % 1: yes NPKG, no CR (should not exist); 2: no NPKG, yes CR; 3: yes NPKG, yes CR
    
    % Find all crops that have ApRnan == 2
    [~,all_missing_crops] = find(ApRnan==2);
    all_missing_crops     = unique(all_missing_crops);

    
    
%% Calculate the average value globally first
    disp('   Global run now')
    sumM = sum(COUR_frate_NEIG{m}.*COUR_CR_HA,'omitnan');
    sumA = sum(COUR_CR_HA,'omitnan');
    eid = find(sumM>0);
    
    for i = all_missing_crops'
        disp(['     Now processing ' CROP_Name{i} ' globally'])
        
        con1 = strcmp(CropClass,CropClass(i));
        con2 = strcmp(TP,TP(i));
        con3 = strcmp(HST,HST(i));
        con = con1 + con2 + con3;
        G = find(con == 3);    % group of all crops satisfy all 3 conditions|175crops
        Ge = eid(find(ismember(eid,G)));   %list of all exist crops|175crops
        disp(['        Three conditions are: ' CropClass{i} ', ' TP{i} ', ' HST{i}]);   

        if ~isempty(Ge)  %if exist crops matches 3 conditions with the misscrop
            conflag(:,i) = 30;
        else 
            G = find(con == 2);    % group of missing crops satisfy 2 conditions|175crops
            Ge = eid(find(ismember(eid,G))); %list of all exist crops|175crops
            if ~isempty(Ge)  %if exist crops matches 2 conditions with the misscrop
                conflag(:,i) = 20;
            else
                G = find(con3 == 1);    % group of missing crops satisfy 1 conditions|175crops
                Ge = eid(find(ismember(eid,G))); %list of all exist crops|175crops
                conflag(:,i) = 10; % only happen for pyrethrum
            end
        end
        disp(['        Number of matched conditions is ' num2str(conflag(1,i)/10)])
        disp(['        Available matched crops are ' num2str(length(Ge)) ': ' CROP_Name{Ge}])
        COUR_frate_global(:,i) = sum(sumM(Ge))./sum(sumA(Ge));
        disp(['        frate = ' num2str(COUR_frate_global(1,i))])
    end
    
    

    
%%% Loop through each country --> each crop --> find groups of available crops as the priority order.
%%% Take average of the fertilizer data of the group --> to the crop
    disp('   Country run now')

    for k = 1 : length(COU_unique)
    %%% Find actual missing crops in this country
        COUR_row = find(strcmp(COU_Name,COU_unique(k)));
        [~,COU_missing_crops] = find(ApRnan(COUR_row,:)==2);
        COU_missing_crops = unique(COU_missing_crops);

        
        if ~isempty(COU_missing_crops)
        %%% Find actual exist crops with fertilizer data in this country
            fer  = COUR_frate_NEIG{m}(COUR_row,:);
            A    = COUR_CR_HA(COUR_row,:);
            sumM = sum(fer.*A,'omitnan');
            sumA = sum(A,'omitnan');
            eid  = find(sumM>0);
    
            for j = 1:length(COU_missing_crops)
                i = COU_missing_crops(j);
                disp(['     Now processing ' CROP_Name{i} ' in ' COU_unique{k}])
                con1 = strcmp(CropClass,CropClass(i));
                con2 = strcmp(TP,TP(i));
                con3 = strcmp(HST,HST(i));
                con = con1 + con2 + con3;
                G = find(con == 3);    % group of all crops satisfy all 3 conditions|175crops
                Ge = eid(find(ismember(eid,G)));   %list of all exist crops|175crops
                disp(['        Three conditions are: ' CropClass{i} ', ' TP{i} ', ' HST{i}]);   
    %%
    
    

    
                if ~isempty(Ge)  %if exist crops matches 3 conditions with the misscrop
                    conflag(COUR_row,i) = 3;
                else 
                    G = find(con == 2);    % group of missing crops satisfy 2 conditions|175crops
                    Ge = eid(find(ismember(eid,G))); %list of all exist crops|175crops
                    if ~isempty(Ge)  %if exist crops matches 2 conditions with the misscrop
                        conflag(COUR_row,i) = 2;
                    elseif ~isempty(find(strcmp(CROP_Name{i},'pyrethrum'))) %if crop is pyrethrum
                        G = find(con3 == 1);    % group of missing crops satisfy 1 conditions|175crops
                        Ge = eid(find(ismember(eid,G))); %list of all exist crops|175crops
                        conflag(COUR_row,i) = 1; % only happen for pyrethrum
                    else  % don't touch conflag, it will be the value of global average 30,20,10
                        disp('        Number of matched conditions is less than 2, take global group average')
                        COUR_frate_cropgroup{m}(COUR_row,i) = COUR_frate_global(COUR_row,i);
                        COUR_set_num{m}(COUR_row,i)  = 11;   %11: CROPGROUP
                        COUR_set_text{m}(COUR_row,i) = {'CROPGROUP'};
                        
%                         disp('--------')
%                         disp('here 1')
%                         COU_unique(k)
%                         COU_missing_crops(j)
%                         pause
                    end
                end

                if and(conflag(COUR_row(1),i)>0, conflag(COUR_row(1),i)<4)
                    disp(['        Number of matched conditions is ' num2str(conflag(COUR_row(1),i))])
                    disp(['        Available matched crops are ' num2str(length(Ge)) ': ' CROP_Name{Ge}])
                    COUR_frate_cropgroup{m}(COUR_row,i) = sum(sumM(Ge))./sum(sumA(Ge));
                    COUR_set_num{m}(COUR_row,i)  = 11;   %11: CROPGROUP
                    COUR_set_text{m}(COUR_row,i) = {'CROPGROUP'};
                    disp(['        frate = ' num2str(COUR_frate_cropgroup{m}(COUR_row(1),i))])
                    
%                         disp('--------')
%                         disp('here 2')
%                         COU_unique(k)
%                         COU_missing_crops(j)
%                         pause

                end
            end
        end
    end
    
%% Synchronize with CROPGRIDS
    [row0 col0] = find(COUR_CR_LO==0);
    
    COUR_frate_cropgroup{m}(COUR_CR_LO==0) = nan;
    for i = 1:size(COUR_CR_LO,1)
        for j = 1:size(COUR_CR_LO,2)
            if COUR_CR_LO(i,j) == 0
                COUR_set_num{m}(i,j)  = 0;
                COUR_set_text{m}{i,j} = ' ';
                %COUR_Qk_ave{m}(i,j)   = 0;
            end
        end
    end


end


sets{11} = 'CROPGROUP';
save('CROPGROUP_COUR_NPK.mat','COUR_frate_cropgroup','COUR_set_text','COUR_set_num','COUR_Qk_ave', 'sets')

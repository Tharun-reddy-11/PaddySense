clear 
close all



folder_here      = cd;
folder_CROPGRIDS = '../DATA/CROPGRIDS';
folder_REMAP     = '../REMAP_0p05x0p05';
folder_FAOSTAT   = '../DATA/FAOSTAT_NPK';
folder_IFASTAT   = '../DATA/IFASTAT';



%%% Load frate 
load('CROPGROUP_COUR_NPK.mat', 'COUR_frate_cropgroup','COUR_set_text','COUR_set_num','COUR_Qk_ave','sets')   
COUR_frate = COUR_frate_cropgroup;  %[kg/ha]  Final name for NPK


% Load CROPGRIDS
cd(folder_CROPGRIDS)
    load CROPGRIDS_Tabulated_HA.mat
    COUR_CR_LO = COUR_CR_HA>0;  % CROPGRIDS mask [ha]
cd(folder_here)
nCROPS = length(CROP_Name);



%%% LOAD COUR
cd(folder_REMAP)
    load('COU.mat','COU_Info')
    tmp         = COU_Info.ImageDescription;
    COU_unique  = cellfun(@(x) extractBetween(x,': ',' >'),tmp,'UniformOutput',false);
    COU_unique  = cellfun(@strtrim,COU_unique,'UniformOutput',false);
    COU_unique  = [COU_unique{:}];
    
    ISO2_unique = cellfun(@(x) extractBetween(x,'- ',','),tmp,'UniformOutput',false);

    load('COUR.mat','COUR_Info')
    tmp       = COUR_Info.ImageDescription;
    COUR_Name = cellfun(@(x) extractAfter(x,'> '),tmp,'UniformOutput',false);
    COUR_Name = strtrim(COUR_Name);
    COU_Name  = cellfun(@(x) extractBetween(x,': ',' >'),tmp,'UniformOutput',false);
    COU_Name  = [COU_Name{:}];
    COUR_iso2 = cellfun(@(x) extractBetween(x,'- ',','),tmp);
    
cd(folder_here)
%clear tmp




%% Correct for values outside bounds

% FROM chatGPT
% give me values for the maximum and minimum N application rate in kg/ha
% N, 15-300 kg/ha
% P2O5, 15-100 kg/ha
% K2O, 15-200 kg/ha

UB = [300 100 200];
LB = [10  5  10];

harea = COUR_CR_HA .*( COUR_CR_HA>0);
ftype = {'N','P2O5','K2O'};

%% THIS REDISTRIBUTE EXCESS APPLICATION RATES TO ALL CROPS WITHIN COUR
for f = 1:length(ftype)
    frate = COUR_frate{f};
    
    %figure(1)
    %hold on
    %plot(log10(frate(~isnan(frate))),'-b','linewidth',4)
    
    MASS = frate .* harea;
    MASS_before_all = nansum(MASS(:));
    
    % identify overestimations
    jU   =  frate > UB(f);
    [j, i] = find(jU);  % identify COUR and CROP in excess
    for z = 1:length(j)
        
        tmp = frate(j(z),:);  % frate in all crops in that COUR
        %MASS_before = nansum(MASS(j(z),:));
        %jL  = (tmp < LB(f)) &  (tmp > 0); 
        jL  = (tmp > 0); 
        if ~isempty(jL)
            DELTA = UB(f) * harea(j(z),i(z)) - MASS(j(z),i(z));
            MASS(j(z), i(z)) = MASS(j(z), i(z)) + DELTA;
              
            MASS(j(z), jL) = MASS(j(z), jL) * ( sum(MASS(j(z), jL)) - DELTA )/sum(MASS(j(z), jL));
            frate(j(z),:) = MASS(j(z),:)./ harea(j(z),:);
        end
        %MASS_after = nansum(MASS(j(z),:));
        
        %disp([MASS_before MASS_after])
        %pause
    end
    MASS_after_all = nansum(MASS(:));
    disp('---- Mass conservation ------')
    disp([MASS_before_all   MASS_after_all])

    
    %plot(log10(frate(~isnan(frate))),'-r','linewidth', 2)
    %pause
    
    COUR_frate{f} = frate;
end








for m = 1:length(ftype)

    tmp = [];
    f=ftype{m};

    
%% Read FAOSTAT and IFASTAT table

    cd(folder_FAOSTAT)
        [~,~,~,ISO2_FAO,~,~,~,~,~,~,~,~,Mean_FAO] = readvars('FAOSTAT_FertilizersUse_2015_2020_avg.xlsx','sheet',f);
    cd(folder_here)
    
    cd(folder_IFASTAT)
        [ISO2_IFA,~,Mean_IFA] = readvars('IFASTAT_FertilizersUse_2015_2020_avg.xlsx','sheet',f);
    cd(folder_here)

    
%% TABLE data 
    COU_mass = [];
    FAO_mass = [];
    IFA_Mass = [];
    for j = 1:length(COU_unique)
        % NPKCHEMGRIDS mass [T]
        COUR_row              = find(strcmp(COU_Name,COU_unique(j)));
        COUR_mass             = COUR_frate{m}(COUR_row,:).*COUR_CR_HA(COUR_row,:);   %[kg/ha*ha=kg]
        COU_mass(j,1)         = sum(COUR_mass(:),'omitnan')/1000; % [T]
        COU_mass(COU_mass==0) = NaN;
        
        %FAOSTAT
        irow = find(strcmp(ISO2_FAO,ISO2_unique{j}));
        if ~isempty(irow)
            FAO_mass(j,1) = Mean_FAO(irow);
        else
            FAO_mass(j,1) = NaN;
        end
        
        %IFASTAT
        irow = find(strcmp(ISO2_IFA,ISO2_unique{j}));
        if ~isempty(irow)
            IFA_mass(j,1) = Mean_IFA(irow);
        else
            IFA_mass(j,1) = NaN;
        end
    end
    
%% Exogenous dataset qualities
    QF =  1 - min(1,abs(COU_mass - FAO_mass)./FAO_mass);
    QI =  1 - min(1,abs(COU_mass - IFA_mass)./IFA_mass);

%% Exogenous dataset qualities matrices
    COUR_QF =  COUR_Qk_ave{m}*nan;
    COUR_QI =  COUR_Qk_ave{m}*nan;
    
    for i=1:length(COU_unique)
        COUR_row = find(strcmp(COU_Name,COU_unique(i)));
        COUR_QF(COUR_row,:) = QF(i);
        COUR_QI(COUR_row,:) = QI(i);
    end
    
%% Final dataset qualities matrices
    %COUR_Qq{m} = (COUR_Qk_ave{m} + COUR_QF + COUR_QI)/3;
    
    tmp(:,:,1) = COUR_Qk_ave{m};
    tmp(:,:,2) = COUR_QF;
    tmp(:,:,3) = COUR_QI;
    COUR_Qq{m} = nanmean(tmp,3);
    clear tmp
    
    
%% Synchronize with CROPGRIDSv1
    COUR_Qq{m}(COUR_CR_LO == 0) = nan;
    
end



save('Final_COUR_NPK_v2.mat','COUR_frate','COUR_set_text','COUR_set_num','COUR_Qq', 'sets','CROP_Name')
